/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pr3car;

/**
 *
 * @author М_З_А
 */
public class CarService {
    public void change(Car car){
    String newCarBrand = car.getCarBrand();
    String newCarBrand2 = newCarBrand.replaceAll("а","о");
    String newCarBrand3 = newCarBrand2.replaceAll("i","e");
    newCarBrand3 = newCarBrand3.toUpperCase();
    car.setCarBrand(newCarBrand3);
    }
}
