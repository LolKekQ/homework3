/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pr3car;

/**
 *
 * @author М_З_А
 */
public class Truck extends Car {
    private String color;
    private double truckHeight;

    public Truck(String color, double truckHeight, int maxSpeed, String carBrand, double carMileage, double stoppingDistance) {
        super(maxSpeed, carBrand, carMileage, stoppingDistance);
        this.color = color;
        this.truckHeight = truckHeight;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getTruckHeight() {
        return truckHeight;
    }

    public void setTruckHeight(double truckHeight) {
        this.truckHeight = truckHeight;
    }
    
    public void quantityOfCargo(int quantityOfCargo){
        System.out.println(quantityOfCargo);
    }
    
    @Override
    public String toString(){
        return "Truck{" + "Brand = " + getCarBrand() + ", max speed = " + getMaxSpeed() + ", car mileage = " + getCarMileage() + ", Stopping distance = " +getStoppingDistance() + ", color =" + getColor() + ", truck height =" + getTruckHeight() + "}";
    }
}
